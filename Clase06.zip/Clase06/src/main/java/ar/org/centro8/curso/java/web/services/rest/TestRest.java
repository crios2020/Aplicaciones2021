package ar.org.centro8.curso.java.web.services.rest;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;


@Path("/rest/")
public class TestRest{
    
    @GET
    @Produces(MediaType.TEXT_PLAIN)
    public String info(){
        return "<h1>Servicio rest Activo!</h1>";
    }
    
    @GET
    @Path("info")
    @Produces(MediaType.TEXT_PLAIN)
    public String info2(){
        return "Método info 2";
    }
    
    @GET
    @Path("saludo")
    @Produces(MediaType.TEXT_HTML)
    public String saludo(@QueryParam("nombre")String n){
        return "<h1>Hola "+n+"</h1>";
    }
    
    @GET
    @Path("calculadora")
    @Produces(MediaType.TEXT_PLAIN)
    public String calculadora(@QueryParam("nro1")int nro1, @QueryParam("nro2")int nro2){
        int resultado=nro1+nro2;
        return resultado+"";
    }
    
}
