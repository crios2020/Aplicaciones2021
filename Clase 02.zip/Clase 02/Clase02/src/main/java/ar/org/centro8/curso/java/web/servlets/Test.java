package ar.org.centro8.curso.java.web.servlets;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.URI;

import javax.persistence.criteria.CriteriaBuilder.In;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Test
 */
public class Test extends HttpServlet {
	private static final long serialVersionUID = 1L;

    /**
     * Default constructor. 
     */
    public Test() {
        // TODO Auto-generated constructor stub
    }
    
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
    	//response.setContentType("image/jpeg");
        try (PrintWriter out = response.getWriter()) {
        	
        	
        	
        	
        	//Como enviar una foto
//        	int by;
//        	try(FileReader in=new FileReader(new File(URI.create("http://localhost:8080/Clase02/img/Rockola 4.jpeg")))){
//        		while((by=in.read())!=-1) {
//        			out.print(by);
//        		}
//        	}
        	
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html lang=es>");
            out.println("<head>");
            out.println("<title>Servlet Test</title>");            
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet Test at " + request.getContextPath() + "</h1>");
            out.println("<h2>Hola Mundo Servlet</h2>");
            String nombre=request.getParameter("nombre");
            if(nombre!=null && !nombre.isEmpty()) {
            	out.println("Hola "+nombre);
            	System.out.println("Se ingreso un parametro!");
            }
            
            //request.getParameterMap().forEach((k,v)->System.out.println(k+" "+v));
            
            //request.getParameterMap().values().forEach(System.out::println);
            
            //request.getParameterMap().forEach((k,v)->out.println(k));
            
            request
            	.getParameterMap()
            	.keySet()
            	.forEach(k->System.out.println(request.getParameter(k)));
            
            
            out.println("</body>");
            out.println("</html>");
        }
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		processRequest(request,response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//doGet(request, response);
		processRequest(request,response);
	}

}
