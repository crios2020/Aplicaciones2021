package clase05cliente;

import ar.org.centro8.curso.java.web.entities.Cliente;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import java.io.IOException;
import java.lang.reflect.Type;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.List;

public class Clase05Cliente {

    public static void main(String[] args) throws Exception{
        // Cliente HTTP Clase
        String server="http://localhost:8084/server/webresources/clientes/v1";
        String url;
        
//        System.out.println("****************************************************");
//        System.out.println("-- Google ");
//        System.out.println("****************************************************");
//        url="http://www.google.com.ar";
//        System.out.println(responseBody(url));
        
        /*
        System.out.println("****************************************************");
        System.out.println("-- Servicio Meterologico Nacional ");
        System.out.println("****************************************************");
        url="https://ws.smn.gob.ar/map_items/weather";
        //url="https://ws.smn.gob.ar/";
        System.out.println(responseBody(url));
        */

        System.out.println("****************************************************");
        System.out.println("-- Server ");
        System.out.println("****************************************************");
        url=server;
        System.out.println(responseBody(url));
        
        
        System.out.println("****************************************************");
        System.out.println("-- ClientesAlta 1");
        System.out.println("****************************************************");
        url=server+"/ClientesAlta?nombre=Juan&apellido=Perez&fenaci=2005/05/05&tipoDocumento=DNI&numeroDocumento=1111915&telefono=222222&email=nada@nada&calle=Viel&numero=10&piso=x&depto=x&codigoPostal=1111&ciudad=CABA&provincia=CABA&pais=Argentina&comentarios=x";
        System.out.println(responseBody(url));
        
        System.out.println("****************************************************");
        System.out.println("-- ClientesAlta 2");
        System.out.println("****************************************************");
        url=server+"/ClientesAlta?nombre=Ana&apellido=Garcia&fenaci=2005/05/05&tipoDocumento=DNI&numeroDocumento=1111815&telefono=222222&email=nada@nada&calle=Viel&numero=10&piso=x&depto=x&codigoPostal=1111&ciudad=CABA&provincia=CABA&pais=Argentina&comentarios=x";
        System.out.println(responseBody(url));
        
        System.out.println("****************************************************");
        System.out.println("-- ClientesAlta 3");
        System.out.println("****************************************************");
        url=server+"/ClientesAlta?nombre=Lorena&apellido=Broca&fenaci=2005/05/05&tipoDocumento=DNI&numeroDocumento=1117115&telefono=222222&email=nada@nada&calle=Viel&numero=10&piso=x&depto=x&codigoPostal=1111&ciudad=CABA&provincia=CABA&pais=Argentina&comentarios=x";
        System.out.println(responseBody(url));
        
        System.out.println("****************************************************");
        System.out.println("-- ClientesAlta 4");
        System.out.println("****************************************************");
        url=server+"/ClientesAlta?nombre=Jose&apellido=Gomez&fenaci=2005/05/05&tipoDocumento=DNI&numeroDocumento=1111615&telefono=222222&email=nada@nada&calle=Viel&numero=10&piso=x&depto=x&codigoPostal=1111&ciudad=CABA&provincia=CABA&pais=Argentina&comentarios=x";
        System.out.println(responseBody(url));

        System.out.println("****************************************************");
        System.out.println("-- ClientesAll ");
        System.out.println("****************************************************");
        url=server+"/ClientesAll";
        System.out.println(responseBody(url));
        
        System.out.println("****************************************************");
        System.out.println("-- ClientesLikeApellido ");
        System.out.println("****************************************************");
        url=server+"/LikeApellido?apellido=go";
        System.out.println(responseBody(url));
        
        
        /*
        System.out.println("*******************************************");
        System.out.println("*******************************************");
        url=server+"/ClientesAll";
        Type listType=new TypeToken<List<Cliente>>(){}.getType();
        List<Cliente>list=new Gson().fromJson(responseBody(url), listType);
        list.forEach(System.out::println);
        */
        
    }
    
    private static String responseBody(String url) throws InterruptedException, IOException {
        HttpClient client = HttpClient.newHttpClient();
        HttpRequest request = HttpRequest
                .newBuilder()
                .uri(URI.create(url))
                .build();
        HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());
        if(response.statusCode()==200){
            System.out.println("\033[32mstatus: "+response.statusCode()+"\033[0m");
        }else{
            System.out.println("\033[31mstatus: "+response.statusCode()+"\033[0m");
        }
        response.headers().map().forEach((k, v) -> System.out.println(k + " " + v));
        return response.body();
    }
}
