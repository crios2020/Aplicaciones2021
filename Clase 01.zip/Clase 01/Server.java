import java.net.ServerSocket;
import java.net.Socket;
import java.io.OutputStream;
public class Server{
	public static void main(String[] args){
		String mensaje="<h1>Servidor de Carlos</h1>";
		mensaje=    "HTTP/1.1 200 OK\n"+
					"Content-Type: text/html\n"+
                    "Content-Length: "+mensaje.length()+"\n\n"
                    +mensaje;
		try(ServerSocket ss=new ServerSocket(8000)){
			while(true){
				System.out.println("Esperando conexión de cliente.....");
				try(
					Socket so=ss.accept();
					OutputStream out=so.getOutputStream();
				){
					out.write(mensaje.getBytes());
				}catch(Exception ex){
					System.out.println(ex);
				}
			}
		}catch(Exception e){
			System.out.println(e);
		}
	}
}
