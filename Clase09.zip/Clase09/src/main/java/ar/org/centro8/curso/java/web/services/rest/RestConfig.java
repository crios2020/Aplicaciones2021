package ar.org.centro8.curso.java.web.services.rest;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;

@ApplicationPath("/webresources")
public class RestConfig extends Application{
    
}
