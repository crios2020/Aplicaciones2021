package ar.org.centro8.curso.java.web.test;

import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class TestJPAConnector {
    public static void main(String[] args) {
        EntityManagerFactory emf=Persistence.createEntityManagerFactory("JPAPU");
        
        emf.close();
    }
}
